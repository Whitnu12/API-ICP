
<?php $__env->startSection('content'); ?>

<h1>mantap bro</h1>

<script>
    // Fetch data dari API
    fetch('/api/user/admin', {
        headers: {
            'Authorization': 'Bearer ' + '<?php echo e(session('user')->token); ?>'
        }
    })
        .then(response => response.json())
        .then(data => {
            // Memperoleh data user admin
            const adminData = data.data.admin;

            // Menampilkan data pada halaman
            const adminName = document.createElement('h2');
            adminName.textContent = 'Admin Name: ' + adminData.nama;
            document.getElementById('admin-info').appendChild(adminName);
        })
        .catch(error => console.error('Error:', error));
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\laravel-icp2\resources\views/home.blade.php ENDPATH**/ ?>