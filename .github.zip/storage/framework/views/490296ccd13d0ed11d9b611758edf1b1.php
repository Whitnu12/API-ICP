
<?php $__env->startSection('content'); ?>
<div class="container flex space-x-64">
    <table id="mataPelajaranTable"class="table-auto">
        <thead>
            <tr>
                <th class="tableCellid">No</th>
                <th class="tableCellid">id</th>
                <th class="tableCellMapel" >NPP</th>
                <th class="tableCellMapel">Nama</th>
                <th class="tableCellMapel" >Email</th>
                <th class="tableCellAction" colspan="2">Action</th>
                
            </tr>
        </thead>
        <tbody id="mataPelajaranBody" class="border">
            <!-- Data mata pelajaran akan ditambahkan di sini -->
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\laravel-icp2\resources\views/admin/guru.blade.php ENDPATH**/ ?>